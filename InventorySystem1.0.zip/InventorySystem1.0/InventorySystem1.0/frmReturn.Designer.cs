﻿namespace InventorySystem1._0
{
    partial class frmReturn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Button1 = new System.Windows.Forms.Button();
            this.btnvewlreturn = new System.Windows.Forms.Button();
            this.btnreturn_clear = new System.Windows.Forms.Button();
            this.btnreturn_remove = new System.Windows.Forms.Button();
            this.btnreturn_save = new System.Windows.Forms.Button();
            this.btnreturnadd = new System.Windows.Forms.Button();
            this.Panel7 = new System.Windows.Forms.Panel();
            this.dtCus_addedlist = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Panel6 = new System.Windows.Forms.Panel();
            this.dtgCus_itemlist = new System.Windows.Forms.DataGridView();
            this.Label26 = new System.Windows.Forms.Label();
            this.txttransactionid = new System.Windows.Forms.TextBox();
            this.GroupBox3 = new System.Windows.Forms.GroupBox();
            this.Label25 = new System.Windows.Forms.Label();
            this.Label24 = new System.Windows.Forms.Label();
            this.txtreturn_address = new System.Windows.Forms.TextBox();
            this.txtreturn_name = new System.Windows.Forms.TextBox();
            this.Panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtCus_addedlist)).BeginInit();
            this.Panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgCus_itemlist)).BeginInit();
            this.GroupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // Button1
            // 
            this.Button1.BackColor = System.Drawing.Color.Transparent;
            this.Button1.ForeColor = System.Drawing.Color.Black;
            this.Button1.Location = new System.Drawing.Point(349, 496);
            this.Button1.Name = "Button1";
            this.Button1.Size = new System.Drawing.Size(88, 26);
            this.Button1.TabIndex = 26;
            this.Button1.Text = "Close";
            this.Button1.UseVisualStyleBackColor = false;
            this.Button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // btnvewlreturn
            // 
            this.btnvewlreturn.BackColor = System.Drawing.Color.Transparent;
            this.btnvewlreturn.ForeColor = System.Drawing.Color.Black;
            this.btnvewlreturn.Location = new System.Drawing.Point(255, 496);
            this.btnvewlreturn.Name = "btnvewlreturn";
            this.btnvewlreturn.Size = new System.Drawing.Size(88, 26);
            this.btnvewlreturn.TabIndex = 25;
            this.btnvewlreturn.Text = "View List";
            this.btnvewlreturn.UseVisualStyleBackColor = false;
            this.btnvewlreturn.Click += new System.EventHandler(this.btnvewlreturn_Click);
            // 
            // btnreturn_clear
            // 
            this.btnreturn_clear.BackColor = System.Drawing.Color.Transparent;
            this.btnreturn_clear.ForeColor = System.Drawing.Color.Black;
            this.btnreturn_clear.Location = new System.Drawing.Point(174, 498);
            this.btnreturn_clear.Name = "btnreturn_clear";
            this.btnreturn_clear.Size = new System.Drawing.Size(75, 23);
            this.btnreturn_clear.TabIndex = 22;
            this.btnreturn_clear.Text = "Clear";
            this.btnreturn_clear.UseVisualStyleBackColor = false;
            this.btnreturn_clear.Click += new System.EventHandler(this.btnreturn_clear_Click);
            // 
            // btnreturn_remove
            // 
            this.btnreturn_remove.BackColor = System.Drawing.Color.Transparent;
            this.btnreturn_remove.ForeColor = System.Drawing.Color.Black;
            this.btnreturn_remove.Location = new System.Drawing.Point(93, 498);
            this.btnreturn_remove.Name = "btnreturn_remove";
            this.btnreturn_remove.Size = new System.Drawing.Size(75, 23);
            this.btnreturn_remove.TabIndex = 23;
            this.btnreturn_remove.Text = "Remove";
            this.btnreturn_remove.UseVisualStyleBackColor = false;
            this.btnreturn_remove.Click += new System.EventHandler(this.btnreturn_remove_Click);
            // 
            // btnreturn_save
            // 
            this.btnreturn_save.BackColor = System.Drawing.Color.Transparent;
            this.btnreturn_save.ForeColor = System.Drawing.Color.Black;
            this.btnreturn_save.Location = new System.Drawing.Point(12, 498);
            this.btnreturn_save.Name = "btnreturn_save";
            this.btnreturn_save.Size = new System.Drawing.Size(75, 23);
            this.btnreturn_save.TabIndex = 24;
            this.btnreturn_save.Text = "Save";
            this.btnreturn_save.UseVisualStyleBackColor = false;
            this.btnreturn_save.Click += new System.EventHandler(this.btnreturn_save_Click);
            // 
            // btnreturnadd
            // 
            this.btnreturnadd.BackColor = System.Drawing.Color.Transparent;
            this.btnreturnadd.ForeColor = System.Drawing.Color.Black;
            this.btnreturnadd.Location = new System.Drawing.Point(12, 249);
            this.btnreturnadd.Name = "btnreturnadd";
            this.btnreturnadd.Size = new System.Drawing.Size(78, 25);
            this.btnreturnadd.TabIndex = 21;
            this.btnreturnadd.Text = "Add";
            this.btnreturnadd.UseVisualStyleBackColor = false;
            this.btnreturnadd.Click += new System.EventHandler(this.btnreturnadd_Click);
            // 
            // Panel7
            // 
            this.Panel7.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.Panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Panel7.Controls.Add(this.dtCus_addedlist);
            this.Panel7.Location = new System.Drawing.Point(12, 280);
            this.Panel7.Name = "Panel7";
            this.Panel7.Size = new System.Drawing.Size(613, 212);
            this.Panel7.TabIndex = 19;
            // 
            // dtCus_addedlist
            // 
            this.dtCus_addedlist.AllowUserToAddRows = false;
            this.dtCus_addedlist.AllowUserToDeleteRows = false;
            this.dtCus_addedlist.AllowUserToResizeColumns = false;
            this.dtCus_addedlist.AllowUserToResizeRows = false;
            this.dtCus_addedlist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtCus_addedlist.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column7});
            this.dtCus_addedlist.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dtCus_addedlist.Location = new System.Drawing.Point(0, 0);
            this.dtCus_addedlist.Name = "dtCus_addedlist";
            this.dtCus_addedlist.Size = new System.Drawing.Size(611, 210);
            this.dtCus_addedlist.TabIndex = 1;
            this.dtCus_addedlist.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtCus_addedlist_CellEndEdit);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Item Id";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Item Name";
            this.Column2.Name = "Column2";
            this.Column2.Width = 120;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Description";
            this.Column3.Name = "Column3";
            this.Column3.Width = 120;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Price";
            this.Column4.Name = "Column4";
            this.Column4.Width = 80;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Quantity";
            this.Column5.Name = "Column5";
            this.Column5.Width = 80;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "Total Price";
            this.Column6.Name = "Column6";
            this.Column6.Width = 80;
            // 
            // Column7
            // 
            this.Column7.HeaderText = "StockoutID";
            this.Column7.Name = "Column7";
            this.Column7.Visible = false;
            // 
            // Panel6
            // 
            this.Panel6.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.Panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Panel6.Controls.Add(this.dtgCus_itemlist);
            this.Panel6.Controls.Add(this.Label26);
            this.Panel6.Controls.Add(this.txttransactionid);
            this.Panel6.Controls.Add(this.GroupBox3);
            this.Panel6.Location = new System.Drawing.Point(12, 12);
            this.Panel6.Name = "Panel6";
            this.Panel6.Size = new System.Drawing.Size(613, 231);
            this.Panel6.TabIndex = 20;
            // 
            // dtgCus_itemlist
            // 
            this.dtgCus_itemlist.AllowUserToAddRows = false;
            this.dtgCus_itemlist.AllowUserToDeleteRows = false;
            this.dtgCus_itemlist.AllowUserToResizeColumns = false;
            this.dtgCus_itemlist.AllowUserToResizeRows = false;
            this.dtgCus_itemlist.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgCus_itemlist.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dtgCus_itemlist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgCus_itemlist.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dtgCus_itemlist.Location = new System.Drawing.Point(1, 120);
            this.dtgCus_itemlist.Name = "dtgCus_itemlist";
            this.dtgCus_itemlist.RowHeadersVisible = false;
            this.dtgCus_itemlist.Size = new System.Drawing.Size(607, 106);
            this.dtgCus_itemlist.TabIndex = 3;
            // 
            // Label26
            // 
            this.Label26.AutoSize = true;
            this.Label26.Location = new System.Drawing.Point(10, 19);
            this.Label26.Name = "Label26";
            this.Label26.Size = new System.Drawing.Size(81, 13);
            this.Label26.TabIndex = 2;
            this.Label26.Text = "Transaction Id :";
            // 
            // txttransactionid
            // 
            this.txttransactionid.Location = new System.Drawing.Point(97, 16);
            this.txttransactionid.Name = "txttransactionid";
            this.txttransactionid.Size = new System.Drawing.Size(488, 20);
            this.txttransactionid.TabIndex = 0;
            this.txttransactionid.TextChanged += new System.EventHandler(this.txttransactionid_TextChanged);
            // 
            // GroupBox3
            // 
            this.GroupBox3.Controls.Add(this.Label25);
            this.GroupBox3.Controls.Add(this.Label24);
            this.GroupBox3.Controls.Add(this.txtreturn_address);
            this.GroupBox3.Controls.Add(this.txtreturn_name);
            this.GroupBox3.Location = new System.Drawing.Point(13, 51);
            this.GroupBox3.Name = "GroupBox3";
            this.GroupBox3.Size = new System.Drawing.Size(589, 63);
            this.GroupBox3.TabIndex = 0;
            this.GroupBox3.TabStop = false;
            this.GroupBox3.Text = "Customer Or Suplier Details";
            // 
            // Label25
            // 
            this.Label25.AutoSize = true;
            this.Label25.Location = new System.Drawing.Point(266, 27);
            this.Label25.Name = "Label25";
            this.Label25.Size = new System.Drawing.Size(51, 13);
            this.Label25.TabIndex = 1;
            this.Label25.Text = "Address :";
            // 
            // Label24
            // 
            this.Label24.AutoSize = true;
            this.Label24.Location = new System.Drawing.Point(6, 27);
            this.Label24.Name = "Label24";
            this.Label24.Size = new System.Drawing.Size(41, 13);
            this.Label24.TabIndex = 1;
            this.Label24.Text = "Name :";
            // 
            // txtreturn_address
            // 
            this.txtreturn_address.Enabled = false;
            this.txtreturn_address.Location = new System.Drawing.Point(323, 24);
            this.txtreturn_address.Name = "txtreturn_address";
            this.txtreturn_address.Size = new System.Drawing.Size(249, 20);
            this.txtreturn_address.TabIndex = 0;
            // 
            // txtreturn_name
            // 
            this.txtreturn_name.Enabled = false;
            this.txtreturn_name.Location = new System.Drawing.Point(53, 24);
            this.txtreturn_name.Name = "txtreturn_name";
            this.txtreturn_name.Size = new System.Drawing.Size(186, 20);
            this.txtreturn_name.TabIndex = 0;
            // 
            // frmReturn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(639, 539);
            this.Controls.Add(this.Button1);
            this.Controls.Add(this.btnvewlreturn);
            this.Controls.Add(this.btnreturn_clear);
            this.Controls.Add(this.btnreturn_remove);
            this.Controls.Add(this.btnreturn_save);
            this.Controls.Add(this.btnreturnadd);
            this.Controls.Add(this.Panel7);
            this.Controls.Add(this.Panel6);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "frmReturn";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Stock Return";
            this.Load += new System.EventHandler(this.frmReturn_Load);
            this.Panel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtCus_addedlist)).EndInit();
            this.Panel6.ResumeLayout(false);
            this.Panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgCus_itemlist)).EndInit();
            this.GroupBox3.ResumeLayout(false);
            this.GroupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.Button Button1;
        internal System.Windows.Forms.Button btnvewlreturn;
        internal System.Windows.Forms.Button btnreturn_clear;
        internal System.Windows.Forms.Button btnreturn_remove;
        internal System.Windows.Forms.Button btnreturn_save;
        internal System.Windows.Forms.Button btnreturnadd;
        internal System.Windows.Forms.Panel Panel7;
        internal System.Windows.Forms.Panel Panel6;
        internal System.Windows.Forms.Label Label26;
        internal System.Windows.Forms.TextBox txttransactionid;
        internal System.Windows.Forms.GroupBox GroupBox3;
        internal System.Windows.Forms.Label Label25;
        internal System.Windows.Forms.Label Label24;
        internal System.Windows.Forms.TextBox txtreturn_address;
        internal System.Windows.Forms.TextBox txtreturn_name;
        internal System.Windows.Forms.DataGridView dtCus_addedlist;
        internal System.Windows.Forms.DataGridView dtgCus_itemlist;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
    }
}